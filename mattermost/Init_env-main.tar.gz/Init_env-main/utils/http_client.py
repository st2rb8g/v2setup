import requests

def send_request(
    method: str,
    url: str,
    headers: dict = None,
    params: dict = None,
    data: dict = None,
    json: dict = None,
    auth_token: str = None,
    timeout: int = 10,
    verbose: bool = False
):
    """
    通用 HTTP 请求方法

    :param method: 请求方法，如 'GET', 'POST', 'PUT', 'DELETE'
    :param url: 完整的请求 URL
    :param headers: 请求头部
    :param params: URL 参数 (?key=value)
    :param data: 表单数据
    :param json: JSON 数据体（用于 POST/PUT）
    :param auth_token: 如果需要授权，自动注入 Authorization header
    :param timeout: 超时时间，默认 10 秒
    :param verbose: 如果为 True，打印请求/响应信息
    :return: `requests.Response` 对象
    """
    if headers is None:
        headers = {}

    # 自动加上 Authorization 头（如果有）
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"

    try:
        response = requests.request(
            method=method.upper(),
            url=url,
            headers=headers,
            params=params,
            data=data,
            json=json,
            timeout=timeout
        )

        if verbose:
            print("➡️ Request:", method.upper(), url)
            print("Headers:", headers)
            print("Params:", params)
            print("JSON:", json or data)
            print("⬅️ Response:", response.status_code)
            print("Body:", response.text)

        return response

    except requests.RequestException as e:
        print(f"❌ HTTP Request Failed: {e}")
        return None
