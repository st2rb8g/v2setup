import os
import importlib

UTILS_DIR = os.path.dirname(__file__)

# 自动导入所有 `*_util.py` 文件
__all__ = []

for filename in os.listdir(UTILS_DIR):
    if filename.endswith("_util.py") and filename != "__init__.py":
        module_name = filename[:-3]  # 去掉 `.py` 后缀
        module = importlib.import_module(f"utils.{module_name}")

        # 获取类名（假设类名和文件名格式一致，例如 `mattermost_util.py` -> `MattermostUtil`）
        class_name = "".join([word.capitalize() for word in module_name.split("_")])
        
        if hasattr(module, class_name):
            globals()[class_name] = getattr(module, class_name)
            __all__.append(class_name)
