# `utils/mattermost_util.py`
from typing import Dict, List
from .http_client import send_request


class MattermostUtil:
    def __init__(self, data):
        self.data = data
        self.base_url = data.get("base_url", "http://localhost:8065")
        self._auth_token = self._login_and_get_authtoken()
        self._teams = []

    def _login_and_get_authtoken(self,login_id_input=None, password_iniput=None):
        """内部方法，自动登录并保存 token，不对外暴露"""
        if login_id_input and password_iniput:
            login_id = login_id_input
            password = password_iniput
        else:
            login_info = self.data.get("login", {})
            login_id = login_info.get("login_id")
            password = login_info.get("password")

        if not login_id or not password:
            raise ValueError("⚠️ login_id 和 password 是必需的")

        resp = send_request(
            method="POST",
            url=f"{self.base_url}/api/v4/users/login",
            json={"login_id": login_id, "password": password},
            verbose=False,
        )

        if resp and resp.status_code == 200:
            token = resp.headers.get("Token")
            if token:
                print("✅ 登录成功，已获取 Token")
                print(f"Token: {token}")
                return token
            else:
                raise RuntimeError("❌ 登录成功但未获取到 Token")
        else:
            raise RuntimeError(
                f"❌ 登录失败: {resp.status_code if resp else 'No Response'}"
            )

    def _authorized_get(self, path,auth_token=None, **kwargs):
        """内部通用 GET 请求（带 Token）"""
        if not auth_token:
            auth_token_ = self._auth_token
        else:
            auth_token_ = auth_token
        
        return send_request(
            method="GET",
            url=f"{self.base_url}{path}",
            auth_token=auth_token_,
            **kwargs,
        )

    def _authorized_post(self, path, json=None,auth_token=None, **kwargs):
        """内部通用 POST 请求（带 Token）"""
        if not auth_token:
            auth_token_ = self._auth_token
        else:
            auth_token_ = auth_token
        return send_request(
            method="POST",
            url=f"{self.base_url}{path}",
            auth_token=auth_token_,
            json=json,
            **kwargs,
        )

    def _delete_a_team(self, team_id):
        return send_request(
            method="DELETE",
            url=f"{self.base_url}/api/v4/teams/{team_id}",
            auth_token=self._auth_token,
            verbose=True,
        )

    def _get_a_team_by_name(self, team_name):
        team = self._authorized_get(f"/api/v4/teams/name/{team_name}")
        if team and team.status_code == 200:
            return team.json()
        else:
            return None

    def _get_a_user_by_username(self, username):
        user = self._authorized_get(f"/api/v4/users/username/{username}")
        if user and user.status_code == 200:
            return user.json()
        else:
            return None

    def _get_a_channel_by_name(self, team_name, channel_name):

        team_id = self._get_a_team_by_name(team_name).get("id")
        channel = self._authorized_get(
            f"/api/v4/teams/{team_id}/channels/name/{channel_name}"
        )
        if channel and channel.status_code == 200:
            return channel.json()
        else:
            return None

    def _get_token_of_test_user(self, username):
        password="12345678"
        email=username+"@example.com"
        return self._login_and_get_authtoken(email, password)

    def create_teams(self, parameters: Dict[str, Dict]):
        for team_key, team_data in parameters.items():
            name = team_data.get("name")
            display_name = team_data.get("display_name")
            team_type = team_data.get("type", "O")  # 默认公开团队

            payload = {"name": name, "display_name": display_name, "type": team_type}

            print(
                f"🚀 正在创建团队: {name} ({display_name})，类型: {'公开' if team_type == 'O' else '私密'}"
            )

            resp = self._authorized_post(
                path="/api/v4/teams", json=payload, verbose=True
            )
            self._teams.append(resp.json())

            if resp.status_code == 201:
                print(f"✅ 团队 '{name}' 创建成功")
            elif resp.status_code == 400:
                if "A team with this URL already exists" in resp.text:
                    print(f"⚠️ 团队 '{name}' 已存在")
                else:
                    print(
                        f"❌ 创建团队 '{name}' 失败，状态码: {resp.status_code if resp else '无响应'}"
                    )

            else:
                print(
                    f"❌ 创建团队 '{name}' 失败，状态码: {resp.status_code if resp else '无响应'}"
                )

    def create_users(self, users: Dict[str, Dict]):
        """
        批量创建用户
        :param users: 例如：
            {
                "User1": {
                    "email": "user1@example.com",
                    "username": "user1",
                    "password": "securepassword",
                    "first_name": "John",
                    "last_name": "Doe",
                    "auth_service": "email"
                },
                "User2": { ... }
            }
        """
        for user_key, user_data in users.items():
            email = user_data.get("email")
            username = user_data.get("username")
            password = user_data.get("password")
            first_name = user_data.get("first_name", "")
            last_name = user_data.get("last_name", "")
            auth_service = user_data.get("auth_service", "email")

            # 确保 email, username, password 是必须的
            if not email or not username or not password:
                print(f"⚠️ 跳过 '{user_key}'，因为缺少必要字段")
                continue

            payload = {
                "email": email,
                "username": username,
                "password": password,
                "first_name": first_name,
                "last_name": last_name,
                "auth_service": auth_service,
            }

            print(f"🚀 创建用户: {username} ({email})")

            resp = self._authorized_post(
                path="/api/v4/users", json=payload, verbose=True
            )

            if resp and resp.status_code == 201:
                print(f"✅ 用户 '{username}' 创建成功")
            elif resp and resp.status_code == 400:
                print(f"⚠️ 用户 '{username}' 已存在或请求无效")
            else:
                print(
                    f"❌ 创建用户 '{username}' 失败，状态码: {resp.status_code if resp else '无响应'}"
                )

    def create_channels(self, channels: Dict[str, Dict]):
        """
        批量创建频道
        :param channels: 例如：
            {
                "General": {
                    "team_name": "team1",
                    "name": "general",
                    "display_name": "General",
                    "purpose": "Main discussion channel",
                    "header": "Welcome to General!",
                    "type": "O"
                },
                "Dev-Updates": { ... }
            }
        """
        for channel_key, channel_data in channels.items():
            team_name = channel_data.get("team_name")
            name = channel_data.get("name")
            display_name = channel_data.get("display_name")
            purpose = channel_data.get("purpose", "")
            header = channel_data.get("header", "")
            channel_type = channel_data.get("type", "O")  # 默认公开

            team_id = self._get_a_team_by_name(team_name).get("id")
            if not team_id or not name or not display_name or not channel_type:
                print(f"⚠️ 跳过 '{channel_key}'，因为缺少必要字段")
                continue

            payload = {
                "team_id": team_id,
                "name": name,
                "display_name": display_name,
                "purpose": purpose,
                "header": header,
                "type": channel_type,
            }

            print(
                f"🚀 创建频道: {name} ({display_name})，类型: {'公开' if channel_type == 'O' else '私密'}"
            )

            resp = self._authorized_post(
                path="/api/v4/channels", json=payload, verbose=True
            )

            if resp and resp.status_code == 201:
                print(f"✅ 频道 '{name}' 创建成功")
            elif resp and resp.status_code == 400:
                print(f"⚠️ 频道 '{name}' 已存在或请求无效")
            else:
                print(
                    f"❌ 创建频道 '{name}' 失败，状态码: {resp.status_code if resp else '无响应'}"
                )

    def add_users_to_team(self, teams: Dict[str, List[str]]):
        """
        批量为团队添加用户
        :param teams: 例如：
            {
                "x-lab": ["user1", "user2"],
                "ai-agent": ["user1", "user2"]
            }
        """
        for team_name, user_names in teams.items():
            team_id = self._get_a_team_by_name(team_name).get("id")
            user_ids = [
                self._get_a_user_by_username(username).get("id")
                for username in user_names
            ]

            if not team_id:
                print(f"⚠️ 找不到团队 '{team_name}'，跳过")
                continue

            for user_id in user_ids:
                payload = {"team_id": team_id, "user_id": user_id}

                print(f"🚀 将用户 {user_id} 加入团队 {team_name} ({team_id})")

                resp = self._authorized_post(
                    path=f"/api/v4/teams/{team_id}/members", json=payload, verbose=True
                )

                if resp and resp.status_code == 201:
                    print(f"✅ 用户 '{user_id}' 成功加入团队 '{team_name}'")
                elif resp and resp.status_code == 400:
                    print(f"⚠️ 用户 '{user_id}' 已在团队 '{team_name}' 中")
                else:
                    print(
                        f"❌ 添加用户 '{user_id}' 失败，状态码: {resp.status_code if resp else '无响应'}"
                    )
    def add_users_to_channel(self, channels: List[Dict]):
        """
        批量为频道添加用户
        :param channels: 例如：
            [
            {
                "team_name": "x-lab",
                "channel_name": "general",
                "users": [
                    "user1",
                    "user2"
                ]
            },
            {
                "team_name": "ai-agent",
                "channel_name": "customer-support",
                "users": [
                    "user1",
                    "user2"
                ]
            }
        ]
        """
        for channel_info in channels:
            team_name = channel_info.get("team_name")
            channel_name = channel_info.get("channel_name")
            user_names = channel_info.get("users", [])

            # 获取 `channel_id`
            channel_id = self._get_a_channel_by_name(team_name, channel_name).get("id")
            if not channel_id:
                print(f"⚠️ 找不到频道 '{channel_name}'（团队: {team_name}），跳过")
                continue

            user_ids = [
                self._get_a_user_by_username(username).get("id")
                for username in user_names
            ]
            if not user_ids:
                print(f"⚠️ 频道 '{channel_name}' 没有用户需要添加，跳过")
                continue

            payload = {"user_ids": user_ids}

            print(f"🚀 正在将 {len(user_ids)} 个用户加入频道 '{channel_name}'（团队: {team_name}）")

            resp = self._authorized_post(
                path=f"/api/v4/channels/{channel_id}/members",
                json=payload,
                verbose=True
            )

            if resp and resp.status_code == 201:
                print(f"✅ 用户成功加入 '{channel_name}'")
            elif resp and resp.status_code == 400:
                print(f"⚠️ 部分用户已在频道 '{channel_name}' 中")
            else:
                print(f"❌ 添加用户到 '{channel_name}' 失败，状态码: {resp.status_code if resp else '无响应'}")
    

    def create_posts(self, posts: List[Dict]):
        """
        批量发送消息到频道
        :param posts: 例如：
            [
                {
                    "user_name": "user1",
                    "team_name": "x-lab",
                    "channel_name": "general",
                    "message": "Hello from user1!"
                },
                {
                    "user_name": "user2",
                    "team_name": "ai-agent",
                    "channel_name": "customer-support",
                    "message": "Hello from user2!"
                }
            ]
        """
        for post_data in posts:
            user_name = post_data.get("user_name")
            team_name = post_data.get("team_name")
            channel_name = post_data.get("channel_name")
            message = post_data.get("message")

            channel_id = self._get_a_channel_by_name(team_name, channel_name).get("id")
            if user_name!="admin":
                auth_token = self._get_token_of_test_user(user_name)
            else:
                auth_token = self._auth_token

            if not channel_id:
                print(f"⚠️ 找不到频道 '{channel_name}'，跳过")
                continue

            payload = {"channel_id": channel_id, "message": message}

            print(f"🚀 发送消息到频道 '{channel_name}' (用户: {user_name})")

            resp = self._authorized_post(
                path="/api/v4/posts", json=payload, auth_token=auth_token, verbose=True
            )

            if resp and resp.status_code == 201:
                print(f"✅ 消息发送成功")
            else:
                print(f"❌ 消息发送失败，状态码: {resp.status_code if resp else '无响应'}")