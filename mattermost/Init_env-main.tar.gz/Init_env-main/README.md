# OSWorld OOD Environment Setup

This repository provides a lightweight framework for initializing the environment of OSWorld OOD applications via API‑driven setup (i.e., using HTTP requests).

## Effect Comparison

| State | Description | Preview |
|:------|:------------|:--------|
| **Raw** | An empty, uninitialized view with no contextual information — represents the default “blank” state before any data is loaded. | ![Raw state — empty without any existing info](./source/raw_image.png) |
| **Aim** | A realistic, populated scenario that simulates actual usage by displaying meaningful sample data, UI elements, and context — illustrating the intended final appearance. | ![Aim state — looks like a real scenario](./source/aim_image.png) |

## Getting Started

To add support for your own application, complete the following three steps:

### 1. Create a Setup Utility  
- Path: `utils/{your_application_name}_util.py`  
- Reference: Use `utils/mattermost_util.py` for structure, naming conventions, and request patterns.

### 2. Define Environment Parameters  
- File: `env_set_parameters.py`  
- Action: Add a new section for your application, mirroring the existing Mattermost configuration.

### 3. Adapt the Setup Script  
- Copy: `mattermost_setup.py` → `{your_application_name}_setup.py`  
- Customize: Update API endpoints, payloads, and any application‑specific logic.

## Running Your Setup

```bash
python {your_application_name}_setup.py
