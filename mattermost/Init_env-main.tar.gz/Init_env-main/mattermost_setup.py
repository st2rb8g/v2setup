import json
import utils

# Read JSON settings file
def load_config(file_path):
    with open(file_path, "r") as f:
        return json.load(f)

# Load config
config = load_config("./env_set_parameters/mattermost.json")

# Ensure required keys
assert "data" in config, "❌ Missing 'data' key in config file."
assert "actions" in config, "❌ Missing 'actions' key in config file."

# Extract data and actions
data = config["data"]
actions = config["actions"]

# ✅ 初始化工具类实例
mm = utils.MattermostUtil(data)

# ✅ 映射字符串动作名到实例方法
ACTION_MAP = {
    "create_teams": mm.create_teams,
    "create_users": mm.create_users,
    "create_channels": mm.create_channels,
    "add_users_to_team": mm.add_users_to_team,
    "add_users_to_channel": mm.add_users_to_channel,
    "create_posts": mm.create_posts,

}

# ✅ 执行动作
def execute_action(action, param):
    if action in ACTION_MAP:
        ACTION_MAP[action](param)
    else:
        print(f"⚠️ Warning: Action '{action}' is not defined.")

# ✅ 主执行逻辑
if __name__ == "__main__":
    for action, param in actions.items():
        execute_action(action, param)
